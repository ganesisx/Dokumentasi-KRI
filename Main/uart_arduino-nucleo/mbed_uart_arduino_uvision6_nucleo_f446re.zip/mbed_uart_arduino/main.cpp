#include "mbed.h"              
 
Serial pc(USBTX, USBRX); // to pc
Serial uart(PA_9, PA_10); //tx rx

int main() {

    while(1) {
        if(uart.readable()) {            
            pc.printf("recv=%c \n", uart.getc());
        }
    }
}